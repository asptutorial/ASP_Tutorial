﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(BootstrapSiteLCD.Startup))]
namespace BootstrapSiteLCD
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
