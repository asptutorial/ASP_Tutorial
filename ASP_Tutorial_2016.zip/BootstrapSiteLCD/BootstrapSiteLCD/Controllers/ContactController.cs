﻿using System.Web.Mvc;

namespace BootstrapSiteLCD.Controllers
{
    public class ContactController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
	}
}