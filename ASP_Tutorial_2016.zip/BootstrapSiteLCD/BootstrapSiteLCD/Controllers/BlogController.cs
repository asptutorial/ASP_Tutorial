﻿using System.Web.Mvc;


namespace BootstrapSiteLCD.Controllers
{
    
    
    public class BlogController : Controller
    {
        
        public ActionResult Home1()
        {
            return View();
        }
    }
}
