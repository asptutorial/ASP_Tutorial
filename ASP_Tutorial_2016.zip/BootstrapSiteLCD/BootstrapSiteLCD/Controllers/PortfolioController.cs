﻿using System.Web.Mvc;


namespace BootstrapSiteLCD.Controllers
{
    
    
    public class PortfolioController : Controller
    {
        
        public ActionResult OneColumn()
        {
            return View();
        }
        
        public ActionResult TwoColumn()
        {
            return View();
        }
    }
}
