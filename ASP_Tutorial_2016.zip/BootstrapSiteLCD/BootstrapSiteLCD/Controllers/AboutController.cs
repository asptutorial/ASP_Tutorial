﻿using System.Web.Mvc;

namespace BootstrapSiteLCD.Controllers
{
    public class AboutController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
	}
}