﻿using System.Web.Mvc;

namespace BootstrapSiteLCD.Controllers
{
    public class ServicesController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
	}
}